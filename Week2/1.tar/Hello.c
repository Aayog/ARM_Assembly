#include<stdio.h>
/* demo.c:  My first C program on a Linux */
int main(void)
{
 printf("Hello! This is a test prgoram.\n");
 return 0;
}
